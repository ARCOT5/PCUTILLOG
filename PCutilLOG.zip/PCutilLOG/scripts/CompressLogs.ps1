﻿# Paths to directories
$logDirectory = "C:\PerformanceLogs"
$tempDirectory = "$logDirectory\Temp"

# Create a temporary directory if it doesn't exist
if (-Not (Test-Path $tempDirectory)) {
    New-Item -Path $tempDirectory -ItemType Directory -Force
}

# Move log files to the temporary directory
Get-ChildItem -Path $logDirectory -Filter "*.txt" | Move-Item -Destination $tempDirectory

# Path to save the compressed file
$compressedFile = "$logDirectory\CompressedLogs_$(Get-Date -Format 'yyyyMMdd_HHmmss').zip"

# Compress the log files
Add-Type -AssemblyName "System.IO.Compression.FileSystem"
[System.IO.Compression.ZipFile]::CreateFromDirectory($tempDirectory, $compressedFile)

# Delete the original log files in the temporary directory
Get-ChildItem -Path $tempDirectory -Filter "*.txt" | Remove-Item

# Remove the temporary directory
Remove-Item -Path $tempDirectory -Recurse

# Keep only the most recent compressed log file and delete older ones
$compressedLogs = Get-ChildItem -Path $logDirectory -Filter "CompressedLogs_*.zip" | Sort-Object LastWriteTime -Descending
$mostRecentLog = $compressedLogs | Select-Object -First 1
$oldLogs = $compressedLogs | Where-Object { $_.FullName -ne $mostRecentLog.FullName }
$oldLogs | Remove-Item
