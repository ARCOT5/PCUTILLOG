﻿# Set thresholds for alerts
$cpuThreshold = 80
$memoryThreshold = 75
$diskThreshold = 85
$gpuThreshold = 80
$gpuVramThreshold = 75

# Get system performance metrics
$cpuUsage = Get-WmiObject -Query "select * from Win32_Processor" | Measure-Object -Property LoadPercentage -Average | Select-Object -ExpandProperty Average
$memoryUsage = (Get-WmiObject -Class Win32_OperatingSystem).TotalVisibleMemorySize - (Get-WmiObject -Class Win32_OperatingSystem).FreePhysicalMemory
$memoryPercentage = [math]::Round(($memoryUsage / (Get-WmiObject -Class Win32_OperatingSystem).TotalVisibleMemorySize) * 100, 2)
$diskUsage = Get-WmiObject -Query "select * from Win32_LogicalDisk where DriveType=3" | ForEach-Object { $_.DeviceID + " " + [math]::Round(($_.Size - $_.FreeSpace) / $_.Size * 100, 2) }
$gpuUsage = Get-Counter '\GPU Engine(*)\Utilization Percentage'
$gpuVramUsage = Get-Counter '\GPU Adapter Memory(*)\Dedicated Usage'
$gpuUsagePercentage = [math]::Round($gpuUsage.CounterSamples[0].CookedValue, 2)
$gpuVramUsagePercentage = [math]::Round(($gpuVramUsage.CounterSamples[0].CookedValue / 1MB) / ((Get-WmiObject -Namespace "root\CIMv2" -Class Win32_VideoController).AdapterRAM / 1MB) * 100, 2)

# Create log directory if it doesn't exist
$logDirectory = "C:\PerformanceLogs"
if (-Not (Test-Path $logDirectory)) {
    New-Item -Path $logDirectory -ItemType Directory -Force
}

# Generate a unique log file name with timestamp
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$logFile = "$logDirectory\PerformanceLog_$timestamp.txt"

# Write the log entry
try {
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] CPU Usage: $cpuUsage%, Memory Usage: $memoryPercentage%, Disk Usage: $diskUsage, GPU Usage: $gpuUsagePercentage%, GPU VRAM Usage: $gpuVramUsagePercentage%"
} catch {
    Write-Error "Failed to write to log file: $_"
}

# Generate alerts if thresholds are exceeded
if ($cpuUsage -gt $cpuThreshold) {
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ALERT: CPU usage exceeded $cpuThreshold%"
}
if ($memoryPercentage -gt $memoryThreshold) {
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ALERT: Memory usage exceeded $memoryThreshold%"
}
$diskUsage | ForEach-Object {
    $diskInfo = $_ -split " "
    $diskPercentage = [double]$diskInfo[1]
    if ($diskPercentage -gt $diskThreshold) {
        Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ALERT: Disk usage exceeded $diskThreshold% on drive $($diskInfo[0])"
    }
}
if ($gpuUsagePercentage -gt $gpuThreshold) {
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ALERT: GPU usage exceeded $gpuThreshold%"
}
if ($gpuVramUsagePercentage -gt $gpuVramThreshold) {
    Add-Content -Path $logFile -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] ALERT: GPU VRAM usage exceeded $gpuVramThreshold%"
}
