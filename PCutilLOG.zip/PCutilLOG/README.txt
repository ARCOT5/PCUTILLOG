this was made by Mason C.
open source project
tweak as needed

1. move the file in #scripts called CompressLogs to the folder called PerformanceLogs
2. Open Task Scheduler: Press Win + R, type taskschd.msc, and press Enter.
3. Import the Scheduled Tasks: "apl", "alpha1sched"
4. In Task Scheduler, go to the "Action" menu and select "Import Task...".
5. Browse to the location where the XML file is saved and select the file (e.g., CompressLogsTask.xml).
6. Click "Open" to import the task.
7. Review and Adjust Task Settings: The "Create Task" window will open with the imported task settings. Review the settings on the "General," "Triggers," "Actions," "Conditions," and "Settings" tabs.
8. Make any necessary adjustments, such as changing the user account under the "General" tab.
9. Save and Enable the Task: Click "OK" to save the imported task.
10. Ensure the task is enabled by checking the "Status" column in Task Scheduler. If it is disabled, right-click the task and select "Enable".
11. You're done